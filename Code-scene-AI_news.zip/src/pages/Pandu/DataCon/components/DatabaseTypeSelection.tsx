// src/pages/Pandu/DataCon/components/DatabaseTypeSelection.tsx
import React, { useState, useEffect } from 'react';
import {
  ArrowLeft,
  ArrowRight,
  Database,
  File,
  Loader,
} from 'lucide-react';
import { resetCurrentProject } from './../../../../api/table';

interface DatabaseTypeSelectionProps {
  formData: any;
  updateFormData: (data: any) => void;
  onNext: () => void;
  onBack: () => void;
}

const DatabaseTypeSelection: React.FC<DatabaseTypeSelectionProps> = ({
  formData,
  updateFormData,
  onNext,
  onBack,
}) => {
  const [isLoading, setIsLoading] = useState<boolean>(false);

  // Data arrays for options.


  const sampleDatabase = [
    { id: 'sample-database', name: 'Sample Database', image: 'https://i.imgur.com/8P9f0rV.png' },
  ];
  const selfHostedDatabases = [
    { id: 'bigquery', name: 'BigQuery', image: 'https://i.imgur.com/LtspHN1.png' },
    { id: 'postgresql', name: 'PostgreSQL', image: 'https://i.imgur.com/JiasqNF.png' },
    { id: 'mysql', name: 'MySQL', image: 'https://i.imgur.com/tKjBUly.png' },
    { id: 'sqlserver', name: 'SQL Server', image: 'https://i.imgur.com/D7AAV19.png' },
    { id: 'clickhouse', name: 'ClickHouse', image: 'https://i.imgur.com/LMjtRYV.png' },
    { id: 'trino', name: 'Trino', image: 'https://i.imgur.com/RyoJU3Z.png' },
    { id: 'snowflake', name: 'Snowflake', image: 'https://i.imgur.com/D1kXdOY.png' },
  ];
  /**
   * When the user clicks on a database option, update the form data.
   * For self-hosted items, the sourceType is set to 'self-hosted'
   * For the sample database, it's set to 'sample-database'.
   */
  const handleDatabaseTypeSelect = (sourceType: string, databaseType: string) => {
    updateFormData({ sourceType, databaseType });
  };

  /**
   * Continue button logic:
   * - If a sample database is chosen, attempt to auto-connect.
   * - Otherwise, proceed to the next wizard step.
   */
  const handleContinue = async () => {
    if (formData.sourceType && formData.databaseType) {
      if (formData.sourceType === 'sample-database') {
        setIsLoading(true);
        try {
          // Reset the current project on the backend.
          await resetCurrentProject();

          // Prepare payload for SaveDataSource mutation with sample credentials.
          const payload = {
            operationName: "SaveDataSource",
            variables: {
              data: {
                type: "POSTGRES",
                  properties: {
                  displayName: "Sample_Neon_DB",
                  host: "ep-black-math-a5524p6u-pooler.us-east-2.aws.neon.tech",
                  port: "5432",
                  user: "sampledb_owner",
                  password: "npg_GX2oCjZztOg1",
                  database: "sampledb",
                },
                // properties: {
                //   displayName: "Sample_Neon_DB",
                //   host: "ep-wandering-base-a5gharvz-pooler.us-east-2.aws.neon.tech",
                //   port: "5432",
                //   user: "neondb_owner",
                //   password: "npg_92CKXEBmAQYs",
                //   database: "neondb",
                // },
              },
            },
            query:
              "mutation SaveDataSource($data: DataSourceInput!) { saveDataSource(data: $data) { type properties __typename } }",
          };

          const res = await fetch("https://tina-api.mannit.co/api/codesmell", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload),
          });
          const result = await res.json();
          console.log("Sample DB SaveDataSource response:", result);

          if (result.errors || !result.data || !result.data.saveDataSource) {
            alert("Sample database connection failed. Please try again.");
            setIsLoading(false);
            return;
          }

          // Wait 1 second to let the backend create the project.
          await new Promise(resolve => setTimeout(resolve, 1000));

          // Update connection details and mark as connected.
          updateFormData({
            connectionDetails: {
              hostname: "ep-wandering-base-a5gharvz-pooler.us-east-2.aws.neon.tech",
              port: "5432",
              databaseName: "neondb",
              username: "neondb_owner",
              password: "npg_92CKXEBmAQYs",
              useSSL: true,
            },
            isConnected: true,
          });

          // Skip the Connection Details step: advance from step 2 to step 4.
          onNext(); // Step 2 -> Step 3
          onNext(); // Step 3 -> Step 4 (Database Explorer)
        } catch (error) {
          console.error("Error connecting to sample DB:", error);
          alert("Error connecting to sample database");
        } finally {
          setIsLoading(false);
        }
      } else {
        onNext();
      }
    }
  };

  // Keep the selection in sync if formData updates externally.
  useEffect(() => {
    // No local selected state required as all options are always displayed.
  }, [formData.sourceType]);

  return (
    <>
      {/* Main Container with both sections */}
      <div className="flex flex-col gap-10 mb-8">
         {/* Section: Sample Database */}
         <div className="animate-fadeIn">
          <h3 className="text-xl font-semibold mb-4 text-purple-800">Sample Database</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
            {sampleDatabase.map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => handleDatabaseTypeSelect('sample-database', item.id)}
                className={`
                  p-4 border-2 rounded-xl flex flex-col items-center justify-center transition-all transform hover:scale-105 hover:shadow-lg
                  ${formData.databaseType === item.id && formData.sourceType === 'sample-database'
                    ? 'border-purple-600 bg-purple-50'
                    : 'border-gray-200 hover:border-purple-300'}
                `}
              >
                <img
                  src={item.image}
                  alt={item.name}
                  className="h-12 object-contain mb-3"
                  loading="lazy"
                />
                <span className="font-medium text-gray-700">{item.name}</span>
              </button>
            ))}
          </div>
        </div>
        {/* Section: Self-hosted Databases */}
        <div className="animate-fadeIn">
          <h3 className="text-xl font-semibold mb-4 text-purple-800">Self-hosted Databases</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
            {selfHostedDatabases.map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => handleDatabaseTypeSelect('self-hosted', item.id)}
                className={`
                  p-4 border-2 rounded-xl flex flex-col items-center justify-center transition-all transform hover:scale-105 hover:shadow-lg
                  ${formData.databaseType === item.id && formData.sourceType === 'self-hosted'
                    ? 'border-purple-600 bg-purple-50'
                    : 'border-gray-200 hover:border-purple-300'}
                `}
              >
                <img
                  src={item.image}
                  alt={item.name}
                  className="h-12 object-contain mb-3"
                  loading="lazy"
                />
                <span className="font-medium text-gray-700">{item.name}</span>
              </button>
            ))}
          </div>
        </div>

       
      </div>

      {/* Navigation Buttons */}
      <div className="flex justify-between mt-8 sticky bottom-0 bg-white py-4 border-t border-gray-100">
        <button
          type="button"
          onClick={onBack}
          className="flex items-center gap-2 px-6 py-2 border border-gray-300 rounded-lg hover:bg-gray-100 transition-colors"
        >
          <ArrowLeft size={18} />
          <span className="font-semibold text-gray-700">Back</span>
        </button>
        <button
          type="button"
          onClick={handleContinue}
          disabled={!formData.sourceType || !formData.databaseType || isLoading}
          className={`
            flex items-center gap-2 px-6 py-2 rounded-lg transition-colors focus:outline-none focus:ring-2 focus:ring-purple-200
            ${formData.sourceType && formData.databaseType && !isLoading
              ? 'bg-gradient-to-r from-purple-600 to-pink-600 text-white hover:from-purple-700 hover:to-pink-700'
              : 'bg-gray-300 text-gray-500 cursor-not-allowed'}
          `}
        >
          {isLoading ? (
            <>
              <Loader size={18} className="animate-spin" />
              <span>Connecting...</span>
            </>
          ) : (
            <>
              <span className="font-semibold">Next</span>
              <ArrowRight size={18} />
            </>
          )}
        </button>
      </div>
    </>
  );
};

export default DatabaseTypeSelection;